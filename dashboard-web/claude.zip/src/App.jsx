import TerrainViewer from "./components/TerrainViewer";

function App() {
  return <TerrainViewer />;
}

export default App;